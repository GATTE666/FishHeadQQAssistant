# 鱼头 QQ 消息助手

一个 OriginOS 7 / 蓝色玻璃拟态风格的 Android Studio 示例工程。

## 当前实现
- 无障碍设置入口。
- 无障碍服务仅监听 QQ（`com.tencent.mobileqq`）窗口事件，用于识别 QQ 是否产生前台窗口事件。
- 不读取聊天文本、不点击控件、不自动发送消息。
- 消息草稿编辑与复制；条数输入限制为 1–100，但不会自动群发。

## 构建
1. 使用 Android Studio 打开本目录。
2. 安装 Android SDK Platform 35。
3. 使用 JDK 17。
4. 等待 Gradle 同步完成。
5. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。

当前交付为源码工程 ZIP。此运行环境没有 Android SDK / Gradle，因此无法在这里直接编译出可安装 APK。
