package com.fishhead.qqassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class QQWatcherService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Privacy-first: only observes that QQ generated a window event.
        // It does not inspect message text, click controls, or send anything.
        event ?: return
        if (event.packageName?.toString() == "com.tencent.mobileqq") {
            MainActivity.qqForeground = true
        }
    }

    override fun onInterrupt() {
        MainActivity.qqForeground = false
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        MainActivity.qqForeground = false
        return super.onUnbind(intent)
    }
}
