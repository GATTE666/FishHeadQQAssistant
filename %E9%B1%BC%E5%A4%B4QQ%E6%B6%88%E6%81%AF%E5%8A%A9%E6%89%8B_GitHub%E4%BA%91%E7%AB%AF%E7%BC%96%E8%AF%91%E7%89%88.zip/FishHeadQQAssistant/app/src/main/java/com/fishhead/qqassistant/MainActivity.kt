package com.fishhead.qqassistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    companion object { @Volatile var qqForeground: Boolean = false }

    private val navy = Color.rgb(8, 20, 48)
    private val blue = Color.rgb(50, 133, 255)
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun rounded(color: Int, radius: Float, stroke: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = radius
            if (stroke != Color.TRANSPARENT) setStroke(1, stroke)
        }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(navy) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
        }
        scroll.addView(page)
        page.addView(label("FISHHEAD  /  TOOLBOX", 11f, 0xFF8DBBFF.toInt(), true))
        page.addView(label("鱼头 QQ 消息助手", 27f, Color.WHITE, true).apply {
            setPadding(0, 8, 0, 4)
        })
        page.addView(label("OriginOS 风格 · 安全消息辅助", 13f, 0xFFB4C8E8.toInt()))
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            background = rounded(0xFF142C59.toInt(), 28f, 0xFF376DB5.toInt())
        }
        val heroParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 22 }
        page.addView(hero, heroParams)
        hero.addView(label("QQ 前台状态", 14f, 0xFFB9D2FF.toInt(), true))
        status = label("尚未检测到 QQ", 21f, Color.WHITE, true).apply { setPadding(0, 8, 0, 4) }
        hero.addView(status)
        hero.addView(label("无障碍服务只识别 QQ 是否在前台，不读取聊天内容、不代替你点击或发送。", 12f, 0xFFB9CBE5.toInt()))
        val access = Button(this).apply {
            text = "开启无障碍识别"
            setTextColor(Color.WHITE)
            background = rounded(blue, 24f)
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        page.addView(access, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 16 })

        page.addView(label("消息草稿", 18f, Color.WHITE, true).apply { setPadding(0, 24, 0, 8) })
        val editor = EditText(this).apply {
            hint = "输入要发送的消息…"
            setTextColor(Color.WHITE); setHintTextColor(0xFF91A8CA.toInt())
            minLines = 3; gravity = Gravity.TOP
            setPadding(15, 14, 15, 14)
            background = rounded(0xFF142443.toInt(), 18f, 0xFF294B7C.toInt())
        }
        page.addView(editor, LinearLayout.LayoutParams(-1, -2))
        val count = EditText(this).apply {
            hint = "草稿条数（1–100）"; setText("1")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(0xFF91A8CA.toInt())
            setPadding(15, 12, 15, 12)
            background = rounded(0xFF142443.toInt(), 16f, 0xFF294B7C.toInt())
        }
        page.addView(count, LinearLayout.LayoutParams(-1, 50).apply { topMargin = 10 })
        val copy = Button(this).apply {
            text = "复制消息草稿"
            setTextColor(Color.WHITE); background = rounded(0xFF2364C7.toInt(), 22f)
            setOnClickListener {
                val message = editor.text.toString().trim()
                val n = count.text.toString().toIntOrNull() ?: 1
                if (message.isEmpty()) {
                    Toast.makeText(this@MainActivity, "请先输入消息内容", Toast.LENGTH_SHORT).show()
                } else if (n !in 1..100) {
                    Toast.makeText(this@MainActivity, "条数请设置为 1–100", Toast.LENGTH_SHORT).show()
                } else {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("消息草稿", message))
                    Toast.makeText(this@MainActivity, "已复制草稿。请在 QQ 中手动粘贴并确认发送。", Toast.LENGTH_LONG).show()
                }
            }
        }
        page.addView(copy, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 12 })
        page.addView(label("安全说明：本工具不批量自动发送、不循环刷屏、不读取聊天记录。条数仅用于草稿规划。", 12f, 0xFF9CB1D0.toInt()).apply {
            setPadding(2, 18, 2, 0)
        })
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val enabled = isServiceEnabled()
        status.text = if (enabled) "无障碍已授权 · 等待 QQ" else "尚未开启无障碍识别"
    }

    private fun isServiceEnabled(): Boolean {
        val expected = "$packageName/${QQWatcherService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, true) }
    }
}
